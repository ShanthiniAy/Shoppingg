package com.shan.ShoppingMallManage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMallManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
