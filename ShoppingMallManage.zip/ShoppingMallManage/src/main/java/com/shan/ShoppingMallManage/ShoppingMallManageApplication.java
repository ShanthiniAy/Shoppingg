package com.shan.ShoppingMallManage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMallManageApplication.class, args);
	}

}
